# StickyNotes
This is similar to the Sticky Notes on Windows or Stickies on Mac. The app uses the Widgets which act as notes. They can be placed anywhere on the screen and can be resized. The user can add items/text to the notes.
<br>
[!["Buy Me A Coffee"](https://www.buymeacoffee.com/assets/img/custom_images/orange_img.png)](https://www.buymeacoffee.com/raghavtilak)
